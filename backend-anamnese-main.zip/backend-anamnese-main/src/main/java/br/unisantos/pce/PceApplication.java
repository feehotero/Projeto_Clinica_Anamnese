package br.unisantos.pce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PceApplication.class, args);
	}

}
