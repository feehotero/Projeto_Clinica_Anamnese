package br.unisantos.pce.user;

public record AuthenticationDTO(String login, String password) {
}
